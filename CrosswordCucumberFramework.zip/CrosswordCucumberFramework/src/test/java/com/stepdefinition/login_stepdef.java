package com.stepdefinition;

import com.baseclass.library;
import com.pages.Login_page;
import com.seleniumutil.SeleniumUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login_stepdef extends library
{
	Login_page lp;
	@Given("^I launched the website$")
	public void i_launched_the_website() throws Throwable 
	{
	    launch_browser();
	    
	}

	@When("^I Click on the login button$")
	public void i_Click_on_the_login_button() throws Throwable 
	{
	   lp=new Login_page(dr);
	   lp.Login();
	}

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String arg1, String arg2) throws Throwable 
	{
		lp=new Login_page(dr);
		lp.Name("sudheeraluri@gmail.com");
		lp.Password("sudheer@123");
	}

	@When("^I clicked on login button$")
	public void i_clicked_on_login_button() throws Throwable 
	{
		lp=new Login_page(dr);
		lp.Login_Btn();
	}

	@Then("^Homepage is displayed$")
	public void homepage_is_displayed() throws Throwable 
	{
		SeleniumUtil su= new SeleniumUtil(dr);
		   su.take_screenshot("C:\\Users\\lenovo\\eclipse-workspace\\CrosswordCucumberFramework\\src\\test\\resources\\screenshots\\homepage.png");
	}
	
}
