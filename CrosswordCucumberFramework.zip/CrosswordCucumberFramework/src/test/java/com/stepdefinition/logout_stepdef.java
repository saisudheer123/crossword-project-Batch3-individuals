package com.stepdefinition;

import com.baseclass.library;
import com.pages.Login_page;
import com.pages.Logout_page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class logout_stepdef extends library
{
	Logout_page lo;
	@Given("^I logged into website$")
	public void i_logged_into_website() throws Throwable 
	{
	  launch_browser();
	  Login_page lp=new Login_page(dr);
	  lp.do_login("sudhakarraoaluri@gmail.com", "sudha@123");
	}

	@When("^I click on the logout button$")
	public void i_click_on_the_logout_button() throws Throwable 
	{
	    lo=new Logout_page(dr);
	    Thread.sleep(900);
	    lo.Logout_Btn();
	    
	}

	@Then("^I will be logged out successfully$")
	public void i_will_be_logged_out_successfully() throws Throwable 
	{
		lo=new Logout_page(dr);
	    lo.Logout_Btn();
	}

}
